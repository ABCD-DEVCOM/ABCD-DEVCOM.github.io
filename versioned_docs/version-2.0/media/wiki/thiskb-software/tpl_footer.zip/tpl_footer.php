﻿<?php
/**
 * Template footer, included in the main and detail files
 */

// must be run from within DokuWiki
if (!defined('DOKU_INC')) die();
?>

<!-- ********** FOOTER ********** -->
<div id="dokuwiki__footer"><div >
	<div style="color:white;background-color:#354C6C;text-align:left;">
		<?php
            // get logo either out of the template images folder or data/media folder
            $logoSize = array();
            $logo = tpl_getMediaFile(array(':wiki:logo.png', ':logo.png', 'images/logo.png'), false, $logoSize);
            // display logo in a link to the home page
            tpl_link(
                wl(),
                '<img src="'.$logo.'" '.$logoSize[3].' alt=""align="left" /> ',
                'accesskey="h" title="[Home]"'
            );
        ?>

		<b>A</b>utomation of li<b>B</b>raries and <b>C</b>enters for <b>D</b>ocumentation based on UNESCO/BIREME ISIS technology<br>
		Supporting information services for Science, Culture and Education
		

		<div style="text-align:right; color:white; font-size:smaller">
			<a href="<?php echo DOKU_BASE; ?>doku.php?id=wiki:about:privacy" title="privacy" style="color: white">Privacy policy</a>
			&nbsp;/&nbsp;
			<a href="<?php echo DOKU_BASE; ?>doku.php?id=wiki:about:copyright" title="copyright" style="color: white">© Copyrights</a>
			&nbsp;/&nbsp;
			<a href="https://dokuwiki.org/" title="Driven by DokuWiki" >
				<img src="<?php echo tpl_basedir(); ?>images/button-dw.png" width="80" height="15" alt="Driven by DokuWiki" />
			</a>
		</div>
	</div>

</div><!-- /footer -->

