#!/bin/bash -e
# 2018-02-14: Created Fred Hommersom
# 2018-02-15: fho: first line is bash in stead of sh (required for linux and [[]] construction
# 2018-03-02: fho: improved help, feedback and error processing if pft generates errors in the outputfile
# 2018-05-07: fho: removed columns check (facilitates embedded linfeeds)
# 2018-05-14: fho: no trailing comma at end of header line (avoids excel empty column)
# 2019-09-03: fho: adjusted default abcd_root for cygwin usage
#
# Stopping the script (exit/return) on errors depends on the invocation.
# This script is for 'subshells' and uses 'exit'.
# The check must be the very first statement!
if [ $_ != $0 ]; then
	# Script is  sourced and he script uses 'exit'
	echo "*** Script does not support 'source' : . ./<scriptname>"
	echo "*** Please invoke as 'subshell'      : ./<scriptname>"
	return
fi
####################################################
# Configuration of internal variables
# - The root of ABCD (the www folder)
abcd_root=/opt/ABCD/www
if [ "$OSTYPE" = "cygwin" ]; then
    abcd_root=/cygdrive/c/zz_apps/ABCD/www
fi
# - The default export pft file
pft_name=csv_bldbnk_for_greenstone
# - The default database name
abcd_db=snrbld
# - The default output depends on the actual dbname and is set later
out_file=
# - The default linewidth for mx. Note that mx wraps if exceeded
mx_line_width=10000
####################################################
# Display usage
display_help() {
	echo "Usage: $(basename "$0") [-h] [-d <dbname>] [-p <pft_file>] [-o out_file]"
	echo "                        [-f <from>] [-t <to>]"
	echo "  -d <dbname>     : Internal name of the database. Default: ${abcd_db}"
	echo "  -p <pft_file>   : Display filename without extension. Default: ${pft_name}"
	echo "                    File <pft_file>_h.txt must contain corresponding header labels"
	echo "                    The pft and txt files must be present in .../www/<db_name>/pfts/en."
	echo "  -o <out_file>   : Output file. Default: <dbname>.csv in the current directory."
	echo "  -f <from>       : Number of the first record to process. Default: 1"
	echo "  -t <to>         : Number of the last record to process. Default: the last db record"
	echo "  -s <search_file>: File with search expression. Path from the current directory"
	echo ""
	echo "Examples: ./$(basename "$0") -d snrbld"
	echo "          ./$(basename "$0") -d snrbld -p csv_bldbnk_for_greenstone"
	echo "          ./$(basename "$0") -d snrbld -p csv_bldbnk_for_greenstone -t 12 -o test.csv"
	echo "          ./$(basename "$0") -d snrbld -p csv_bldbnk_for_greenstone -s ../search.txt"
	echo ""
	echo "Note 1  : Internal variable abcd_root is configured as ${abcd_root}"
	echo "Note 2  : Internal variable mx_line_width is configured as ${mx_line_width}"
	echo "Note 3  : The search expression file contains for example '(NA_BONTHUIS, J.A.)  and (ST_OK)'"
	exit 0
}
if [ "$1" = "?" ] || [ "$1" = "-h" ]; then
    display_help
	exit 0
fi

# Read command line parameters
while getopts ":d:o:p:f:t:s:h" opt; do
    case "$opt" in
    h)  display_help
	    exit 0
        ;;
    d)  abcd_db=$OPTARG
        ;;
    o)  out_file=$OPTARG
        ;;
    p)  pft_name=$OPTARG
        ;;
    f)  from_number=$OPTARG
        ;;
    t)  to_number=$OPTARG
        ;;
    s)  search_file=$OPTARG
        ;;
	:)  echo "*** Missing argument for option: -$OPTARG.  Use -h for help" && exit 1 ;;
	"?") echo "*** Invalid option: -$OPTARG. Use -h for help" && exit 1 ;;
    esac
done
# Check for positional parameters (not used in this script)
# Uses the [[...]] construction to cope with embedded erronuous positional parameters
shift $((OPTIND-1))
if [[ ! -z $@ ]]; then 
	echo "*** Superfluous positional parameter(s) at: $@. Use -h for help"
	exit 1
fi

# Derived parameters
if [ "${out_file}" = "" ]; then
	out_file=${abcd_db}.csv
fi
out_err_file=${out_file}.err
out_tmp_file=${out_file}.tmp
abcd_base=${abcd_root}/bases
abcd_cgi_dir=${abcd_root}/cgi-bin
abcd_mx_cmd=${abcd_cgi_dir}/mx
abcd_data_dir=${abcd_base}/${abcd_db}/data
abcd_pfts_dir=${abcd_base}/${abcd_db}/pfts/en
pft_file_name=${pft_name}.pft
pft_h_file_name=${pft_name}_h.txt

# Check the required files: The root database folder
if [ ! -d "${abcd_root}" ]; then
    echo "*** ABCD www root folder '${abcd_root}' does not exist."
	exit 1
fi
# Check the required files: The database .mst file
if [ ! -f "${abcd_data_dir}/${abcd_db}.mst" ]; then
    echo "*** Unable to find database '${abcd_db}.mst' in ${abcd_data_dir}"
	exit 1
fi
# Check the required files: The display file and corresponding header file
if [ ! -f "${abcd_pfts_dir}/${pft_file_name}" ]; then
    echo "*** Unable to find display file '${pft_file_name}' in ${abcd_pfts_dir}"
	exit 1
fi
if [ ! -f "${abcd_pfts_dir}/${pft_h_file_name}" ]; then
    echo "*** Unable to find display file '${pft_h_file_name}' in ${abcd_pfts_dir}"
	exit 1
fi
# Check the required files: The cgi directory (for the mx command)
if [ ! -d "${abcd_cgi_dir}" ]; then
    echo "*** Unable to find location for mx command '${abcd_cgi_dir}'"
	exit 1
fi
# Check the optional files: The search file
if [ ! -z "${search_file}" ] &&  [ ! -f "${search_file}" ]; then
	echo "*** Unable to find file with search expression '${search_file}'"
	exit 1
fi

# Create filenames for mx command (in windows must be dos-like)
# The OS can be detected by the OSTYPE and converted by utility cygpath
mx_db_path=${abcd_data_dir}/${abcd_db}
mx_pft_path=${abcd_pfts_dir}/${pft_file_name}
mx_bool_path=${search_file}
if [ "$OSTYPE" = "cygwin" ]; then
	mx_db_path=`cygpath -w ${abcd_data_dir}/${abcd_db}`
	mx_pft_path=`cygpath -w ${abcd_pfts_dir}/${pft_file_name}`
	if [ ! -z ${search_file} ]; then
		mx_bool_path=`cygpath -w ${search_file}`
	fi
	
fi
# Convert from/to/linewidth/search file into parameter strings for mx
if [ "${from_number}" != "" ]; then
	from_param="from=${from_number}"
fi
if [ "${to_number}" != "" ]; then
	to_param="to=${to_number}"
fi
if [ "${mx_line_width}" != "" ]; then
	lw_param="lw=${mx_line_width}"
fi
if [ "${search_file}" != "" ]; then
	bool_param="btell=0 bool=@${mx_bool_path}"
fi

echo "$(basename "$0"): OK for database   : ${abcd_db}"
echo "$(basename "$0"): OK for export pft : ${pft_file_name}"
if [ "${search_file}" != "" ]; then
	echo "$(basename "$0"): OK for search file: ${search_file}" with content:
	cat ${search_file}
	echo ""
else
	echo "$(basename "$0"): No search file specified"
fi 

###############################################
# The generation of the output
# removal of a possible existing output file
#
if [ -f ${out_file} ]; then
	echo "$(basename "$0"): Removing previous output file : ${out_file}"
	rm ${out_file}
fi
if [ -f ${out_err_file} ]; then
	echo "$(basename "$0"): Removing previous error file  : ${out_err_file}"
	rm ${out_err_file}
fi
if [ -f ${out_tmp_file} ]; then
	echo "$(basename "$0"): Removing previous scratch file: ${out_tmp_file}"
	rm ${out_tmp_file}
fi

# Converting the _h.txt file to a single header line in CSV format
# The non-standard IFS clause ensures splitting at linux \n or windows \r\n
# The special while construction allows files without ending LF or CRLF
#
echo "$(basename "$0"): Writing header lines from ${pft_h_file_name} to ${out_file}"
count=0
while IFS=$'\r\n' read -r line || [[ -n "$line" ]]; do
	if [ "$count" != "0" ]; then
		printf ',' "$line" >> ${out_tmp_file}
	fi
    printf '\"%s\"' "$line" >> ${out_tmp_file}
	count=$((count+1))
done < "${abcd_pfts_dir}/${pft_h_file_name}"
printf "\n" >> ${out_tmp_file}
echo "$(basename "$0"): Extracted $count columns from ${pft_h_file_name}"

# The actual mx command to list the database to the scratch file
echo "$(basename "$0"): Executing: ${abcd_mx_cmd} ${mx_db_path} ${from_param} ${to_param} ${lw_param} ${bool_param} now pft=@${mx_pft_path}"
${abcd_mx_cmd} ${mx_db_path} ${from_param} ${to_param} ${lw_param} ${bool_param} now pft=@${mx_pft_path} >> ${out_tmp_file}

# The generated scratch file may contain errors
# The pattern of these errors comes from the pft file: the pattern in the pft must be equal to the pattern in this script
# Next command filters the errors into an error file.
# Due to the greedy match of sed we see only the last error on a line with multiple errors
grep  '|__:.*:__|' ${out_tmp_file}|sed -n -e 's/^.*|__://' -e 's/:__|.*$//p' > ${out_err_file}

# If the error file exists: filter the non-error text from scratch into the output
# Else move the scratch to the output
if [ -s ${out_err_file} ]; then
    echo "$(basename "$0"): *** Error file ${out_err_file} contains `cat ${out_err_file}|wc -l` lines. ***"
    echo "$(basename "$0"): *** Multiple errors in one output line show only the last error in ${out_err_file} ***"
    echo "$(basename "$0"): *** Update ${pft_file_name} / ${pft_h_file_name} to resolve ***"
    echo "$(basename "$0"): *** Rerun this script after update to show next set of errors ***"
	# The current pft has 7 repeating fields: a global sed required.
	# Note that we faked the greedy match here by [^|]* instead of .*
	# This implies that the pft should not generate error tekst with embedded | signs.
    echo "$(basename "$0"): Filtering scratch ${out_tmp_file} to ${out_file} (removes error substrings)..."
	sed -e 's/|__:[^|]*:__|//g' <${out_tmp_file} >${out_file}
	echo "$(basename "$0"): Removing scratch file: ${out_tmp_file}"
	rm ${out_tmp_file}
else
	echo "$(basename "$0"): Moving scratch file  : ${out_tmp_file} to ${out_file}"
    mv ${out_tmp_file} ${out_file}
fi

# finishing touch: tell success or error
if [ -f ${out_file} ]; then
    echo "$(basename "$0"): Output file          : ${out_file} contains `cat ${out_file}|wc -l` lines (includes header line)."
    echo "$(basename "$0"): Successfully finished."
    exit 0
fi
echo "$(basename "$0"): *** No output file ***"
exit 1


